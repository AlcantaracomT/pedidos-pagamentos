import { Stack } from "expo-router";
import { colors } from "@/theme";

export default function RootLayout() {
  return (
    <Stack
      screenOptions={{
        headerTitleAlign: "center",
        headerShadowVisible: false,
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text,
        headerTitleStyle: { fontSize: 14, fontWeight: "700" },
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen name="index" options={{ title: "CARRINHO" }} />
      <Stack.Screen name="payment" options={{ title: "CARRINHO" }} />
      <Stack.Screen name="pix" options={{ title: "Pagamento via Pix" }} />
    </Stack>
  );
}
