import { CouponApplied, PrimaryButton, PurchaseSummary, SectionTitle, checkoutStyles } from "@/components/checkout-ui";
import { colors } from "@/theme";
import { Ionicons } from "@expo/vector-icons";
import { Href, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

const products = [
  {
    id: 1452,
    name: "Copo da Felicidade",
    description: "Copo com brigadeiro, morango e creme",
    price: 18,
    image: require("../../assets/images/copoFelicidade.png"),
  },
  {
    id: 1845,
    name: "Brownie Cremoso",
    description: "Chocolate 70%, manteiga e leite condensado",
    price: 15,
    image: require("../../assets/images/brow.png"),
  },
];

export default function Orders() {
  const router = useRouter();
  const [quantities, setQuantities] = useState([1, 1]);
  const subtotal = useMemo(
    () =>
      products.reduce(
        (sum, product, index) => sum + product.price * quantities[index],
        0,
      ),
    [quantities],
  );

  const changeQuantity = (index: number, amount: number) => {
    setQuantities((current) =>
      current.map((quantity, itemIndex) =>
        itemIndex === index ? Math.max(1, quantity + amount) : quantity,
      ),
    );
  };

  return (
    <View style={checkoutStyles.screen}>
      <ScrollView contentContainerStyle={checkoutStyles.content}>
        <View style={styles.store}>
          <Image
            source={require("../../assets/images/loja.png")}
            style={styles.storeImage}
          />
          <View>
            <Text style={styles.storeName}>JP Confeitaria</Text>
            <Text style={styles.storeLink}>Ir para loja</Text>
          </View>
        </View>

        <SectionTitle>Itens (Pedido #1452)</SectionTitle>
        {products.map((product, index) => (
          <View key={product.id} style={styles.product}>
            <Image source={product.image} style={styles.productImage} />
            <View style={styles.productInfo}>
              <Text style={styles.productName}>{product.name}</Text>
              <Text style={styles.description} numberOfLines={1}>
                {product.description}
              </Text>
              <Text style={styles.price}>R$ {product.price},00</Text>
            </View>
            <View style={styles.counter}>
              <Pressable
                hitSlop={8}
                onPress={() => changeQuantity(index, -1)}
              >
                <Ionicons
                  name={quantities[index] === 1 ? "trash-outline" : "remove"}
                  size={16}
                  color={colors.primary}
                />
              </Pressable>
              <Text style={styles.quantity}>{quantities[index]}</Text>
              <Pressable hitSlop={8} onPress={() => changeQuantity(index, 1)}>
                <Ionicons name="add" size={17} color={colors.primary} />
              </Pressable>
            </View>
          </View>
        ))}

        <CouponApplied />
        <PurchaseSummary
          subtotal={subtotal}
          delivery={5}
          discount={10}
        />
      </ScrollView>

      <View style={checkoutStyles.footer}>
        <PrimaryButton
          title="Próximo"
          onPress={() => router.push("/payment" as Href)}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  store: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    marginBottom: 26,
  },
  storeImage: {
    width: 58,
    height: 58,
    borderRadius: 29,
  },
  storeName: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "700",
  },
  storeLink: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: "600",
    marginTop: 3,
  },
  product: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },
  productImage: {
    width: 62,
    height: 62,
    borderRadius: 31,
    marginRight: 12,
  },
  productInfo: {
    flex: 1,
    paddingRight: 8,
  },
  productName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  description: {
    color: colors.muted,
    fontSize: 11,
    marginVertical: 3,
  },
  price: {
    color: colors.success,
    fontSize: 13,
    fontWeight: "700",
  },
  counter: {
    minWidth: 70,
    height: 30,
    paddingHorizontal: 8,
    borderRadius: 7,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: colors.surface,
  },
  quantity: {
    color: colors.text,
    fontSize: 13,
    fontWeight: "600",
  },
});
